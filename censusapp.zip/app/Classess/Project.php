<?php

namespace App\Classes;

class Project{
    public $id;

    // public function project_id(){
    //     return $id;
    // }
}