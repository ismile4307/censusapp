<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SurveyFilter extends Model
{
    protected $table='survey_filters';
    use HasFactory;
}
